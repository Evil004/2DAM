package com.oscar.coffeshops

class CoffeShop(name:String,address:String, img: Int) {
    val name = name;
    val address = address;
    val img = img

    constructor() : this("", "", 0)

}